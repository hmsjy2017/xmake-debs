template("xcode.bundle")
    add_configfiles("xmake.lua")
