template("xcode.macapp")
    add_configfiles("xmake.lua")
