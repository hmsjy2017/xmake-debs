template("qt.console")
    add_configfiles("xmake.lua")

