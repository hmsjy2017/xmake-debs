//
//  AppDelegate.h
//  test3
//
//  Created by ruki on 2020/4/4.
//  Copyright © 2020 tboox. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

