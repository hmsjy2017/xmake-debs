#ifndef QT_DEMO_H
#define QT_DEMO_H

class QtDemo
{

public:
    QtDemo();
};

#endif // QT_DEMO_H
