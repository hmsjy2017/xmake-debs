#import <Foundation/Foundation.h>

FOUNDATION_EXPORT int add(int a, int b);
