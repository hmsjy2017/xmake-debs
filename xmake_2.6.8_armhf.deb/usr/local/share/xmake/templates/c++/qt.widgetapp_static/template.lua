template("qt.widgetapp_static")
    add_configfiles("xmake.lua")

