template("xcode.iosapp_with_framework")
    add_configfiles("xmake.lua")
