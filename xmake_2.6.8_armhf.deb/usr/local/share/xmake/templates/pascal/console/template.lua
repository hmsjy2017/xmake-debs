template("console")
    add_configfiles("xmake.lua")
