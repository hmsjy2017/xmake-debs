
-- set repository description
set_description("The official builtin package repository of xmake")
