#import "test.h"
#import <Foundation/Foundation.h>

int add(int a, int b)
{
    NSLog(@"add(%d, %d)", a, b);
    return a + b;
}

