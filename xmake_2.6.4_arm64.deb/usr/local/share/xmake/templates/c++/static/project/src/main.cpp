#include "interface.h"
#include <iostream>

using namespace std;

int main(int argc, char** argv)
{
    cout << "add(1, 2) = " << add(1, 2) << endl;
    return 0;
}
